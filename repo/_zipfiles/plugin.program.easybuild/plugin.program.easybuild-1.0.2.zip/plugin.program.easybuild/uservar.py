import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/Familyeasybuild/wizard-easybuild/master/builds/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/Familyeasybuild/wizard-easybuild/master/builds/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
