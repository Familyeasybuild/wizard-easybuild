'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/Familyeasybuild/wizard-easybuild/master/builds/builds.json'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/Familyeasybuild/wizard-easybuild/master/builds/notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
