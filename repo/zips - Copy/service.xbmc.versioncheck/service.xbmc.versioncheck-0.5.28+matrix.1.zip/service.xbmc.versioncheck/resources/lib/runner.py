# -*- coding: utf-8 -*-

"""

    Copyright (C) 2019 Team Kodi

    This file is part of service.xbmc.versioncheck

    SPDX-License-Identifier: GPL-3.0-or-later
    See LICENSES/GPL-3.0-or-later.txt for more information.

"""

from version_check import service  # pylint: disable=import-error

service.run()
