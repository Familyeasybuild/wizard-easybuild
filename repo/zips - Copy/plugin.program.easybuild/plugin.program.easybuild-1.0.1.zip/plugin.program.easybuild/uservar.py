import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://wizardeasybuild.000webhostapp.com/family/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://wizardeasybuild.000webhostapp.com/family/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
